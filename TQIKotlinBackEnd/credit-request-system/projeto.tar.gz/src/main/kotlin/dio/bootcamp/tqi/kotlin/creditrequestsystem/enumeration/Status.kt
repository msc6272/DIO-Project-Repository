package dio.bootcamp.tqi.kotlin.creditrequestsystem.enumeration

enum class Status {
    IN_PROGRESS, APPROVED, REJECTED
}