package dio.bootcamp.tqi.kotlin.creditrequestsystem

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CreditRequestSystemApplicationTests {

	@Test
	fun contextLoads() {
	}

}
